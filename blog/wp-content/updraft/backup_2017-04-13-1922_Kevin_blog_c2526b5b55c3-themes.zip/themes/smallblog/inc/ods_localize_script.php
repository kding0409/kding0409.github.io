<?php

/**
 * Localize a script for the javascript global file.
 *
 * @since 1.0.0
 *
 */
wp_localize_script( 'global', 'objectL10n', array(
    'back' => __( 'Back', 'smallblog' )
) );